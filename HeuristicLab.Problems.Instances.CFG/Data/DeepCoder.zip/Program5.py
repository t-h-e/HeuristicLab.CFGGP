# *****************************************************************************
# Helper Code
# *****************************************************************************
### First Order
def head(xs):
    return xs[0] if len(xs) > 0 else 0

def last(xs):
    return xs[-1] if len(xs) > 0 else 0

def take(n, xs):
    return xs[:n]

def drop(n, xs):
    return xs[n:]

def access(n, xs):
    return xs[n] if len(xs) > n >= 0 else 0

def minimum(xs):
    return min(xs) if len(xs) > 0 else 0

def maximum(xs):
    return max(xs) if len(xs) > 0 else 0

def reverse(xs):
    return list(reversed(xs))

def sort(xs):
    return sorted(xs)

# def sum(xs):
#     return sum(xs)

### Higher order
def map(f, xs):
    return [f()(x) for x in xs]

def filter(f, xs):
    return [x for x in xs if f()(x)]

def count(f, xs):
    return len([x for x in xs if f()(x)])

def zipwith(f, xs, ys):
    return [f()(x, y) for (x, y) in zip(xs, ys)]

def scanl1(f, xs):
    if len(xs) == 0:
        return []
    ys = [0] * len(xs)
    ys[0] = xs[0]
    for n in range(1, len(xs)):
        ys[n] = f()(ys[n - 1], xs[n])
    return ys


### Lambdas int
def plus1():
    return lambda x: x + 1
def minus1():
    return lambda x: x - 1
def times2():
    return lambda x: x * 2
def div2():
    return lambda x: x // 2
def timesminus1():
    return lambda x: x * (-1)
def square():
    return lambda x: x ** 2
def times3():
    return lambda x: x * 3
def div3():
    return lambda x: x // 3
def times4():
    return lambda x: x * 4
def div4():
    return lambda x: x // 4

### Lambdas bool
def greater_than():
    return lambda x: x > 0
def less_than():
    return lambda x: x < 0
def even():
    return lambda x: x % 2 == 0
def odd():
    return lambda x: x % 2 == 1

### Lambdas pairs of int
def add_pair():
    return lambda x, y: x + y
def subtract_pair():
    return lambda x, y: x - y
def multiply_pair():
    return lambda x, y: x * y
def max_pair():
    return lambda x, y: max(x, y)
def min_pair():
    return lambda x, y: min(x, y)

# *****************************************************************************

#  evolved function
def evolve(in0):
  # stop.value is a boolean flag which should be used to check if the EA wants the program to stop.value
  <insertCodeHere>
  return res0


def fitnessTrainingCase(i, o):
  eval = evolve(i[0])

  #return [abs(eval - o[0])]
  return [abs(x[0] - x[1]) for x in zip(eval, o[0])] + ([5000] * (len(o[0]) - len(eval)) + [0] if len(o[0]) > len(eval) else [5000 * (len(eval) - len(o[0]))])


#  function to evaluate fitness
def fitness():
  error = []
  cases = []
  for (i, o) in zip(inval, outval):
    values = fitnessTrainingCase(i, o)
    error.extend(values)
    cases.append(all(v < 0.000000001 for v in values))

  return error, cases


import sys
quality = sys.maxsize
caseQuality, cases = fitness()
quality = sum(caseQuality)
